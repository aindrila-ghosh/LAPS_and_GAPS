## Imports

import os
import sys

sys.path.append(".")

import warnings
warnings.filterwarnings('ignore')

import math
import numpy as np
import pandas as pd
from sklearn.manifold import TSNE
from .LAPS_tabular import LapsExplainer
from .GAPS_tabular import GapsExplainer
from scipy.spatial.distance import pdist
from bokeh.plotting import figure, ColumnDataSource
from bokeh.models import HoverTool
from bokeh.models.glyphs import Text
from bokeh.layouts import row
from sklearn.neighbors import NearestNeighbors

## Import local files

from .Preprocessing import set_features_and_target, identify_and_transform_features
from .Explanation import explain_point_local, explain_point_global
from .genericMethods import get_neighborhood_plots_LAPS, gen_feature_influence_plots
from .GAPS_Explanation import get_local_explanations_for_GAPS, compute_local_divergences
from django.contrib.staticfiles.storage import staticfiles_storage

def obtain_neighborhood(data, ld_embedding, nbrs, data_instance_number = 85):

	## Set features and target

	model_features, target = set_features_and_target(data)
	y = (data[target].values.reshape(-1, ))
	X_df = pd.DataFrame(data, columns=model_features)

	## Identify categorical features
	X_transformed, categorical_features, numeric_features, categorical_names = identify_and_transform_features(data, model_features)

	num_samples = int(5000/nbrs)
        
	knn = NearestNeighbors(leaf_size=30, n_neighbors=nbrs, p=2, radius=1.0, algorithm='ball_tree')
	knn.fit(X_transformed)
	neighbors = knn.kneighbors(X_transformed, return_distance=False)[data_instance_number]

	knn.fit(ld_embedding)
	neighbors_embd = knn.kneighbors(ld_embedding, return_distance=False)[data_instance_number]

	return neighbors, neighbors_embd


def run_LAPS(data, algo, data_instance_number = 85):

	algorithms = algo.split(',')
	print(algorithms)
	## Set features and target

	model_features, target = set_features_and_target(data)
	y = (data[target].values.reshape(-1, ))
	X_df = pd.DataFrame(data, columns=model_features)

	## Identify categorical features
	X_transformed, categorical_features, numeric_features, categorical_names = identify_and_transform_features(data, model_features)

	## Instantiate LAPS explainer

	explainer = LapsExplainer(X_df.values,
						    feature_names=model_features,
						    class_names=target,
						    categorical_features=categorical_features,
						    categorical_names=categorical_names,
						    discretize_continuous=False,
						    discretizer='quartile',
						    random_state=42)

	## generate perturbed neighborhood
	all_corr_feat_dist_embd = []
	all_feature_dict_embd = []

	for algo in algorithms:

		df = pd.read_csv(staticfiles_storage.path("idle/temp/embedding_"+algo+".csv"))
		ld_embedding = np.array(df[['0', '1', '2']])

		neighbors, globals()["neighbors_embd_"+algo], oversampled_data, globals()["oversampled_data_embd_"+algo] = explainer.generate_perturbed_neighborhood(
																				    X_df.values,
																				    X_transformed,
																				    ld_embedding,
																				    data_instance_number,
																				    X_df.values[data_instance_number],
																				    nbrs=20,
																				    num_features=5)

		## Explain the Neighborhoods in Original and Embedding
	
		globals()["corr_feat_dist_embd_"+algo], globals()["feature_dict_embd_"+algo], globals()["feature_distance_contribution_embd_"+algo], globals()["dvs_matrix_embd_"+algo], globals()["sorted_indexes_embd_"+algo] = explain_point_local(X_df.values[data_instance_number], globals()["neighbors_embd_"+algo], globals()["oversampled_data_embd_"+algo], model_features, categorical_features, numeric_features)
		all_corr_feat_dist_embd.append(globals()["corr_feat_dist_embd_"+algo])
		all_feature_dict_embd.append(globals()["feature_dict_embd_"+algo])

	corr_feat_dist, feature_dict, feature_distance_contribution, dvs_matrix, sorted_indexes = explain_point_local(X_df.values[data_instance_number], neighbors, oversampled_data, model_features, categorical_features, numeric_features)


	## Compute LAPS Divergence
	all_divergences = []
	all_divergence_components = []
	for algo in algorithms:
		components = ""
		disagreement_component1 = pdist([corr_feat_dist, globals()["corr_feat_dist_embd_"+algo]], metric='euclidean')
		disagreement_component1 = 1/(1+disagreement_component1[0])

		components = components + str(disagreement_component1)

		print("Neighbors Algo: ", )
		disagreement_component2 = len(neighbors)-len(np.intersect1d(neighbors, globals()["neighbors_embd_"+algo]))
		print("###################")

		print("Algorithm: "+ algo +" False / Missing Neighbor: "+str(disagreement_component2))

		print("Neighbors Original: ", neighbors)
		print("Neighbors Algo: ", globals()["neighbors_embd_"+algo])

		print("###################")
		disagreement_component2 = disagreement_component2/len(neighbors)

		components = components + "," + str(disagreement_component2)

		disagree = 0
		for index in range (0,len(neighbors)):
		    if neighbors[index] != globals()["neighbors_embd_"+algo][index]:
		        disagree = disagree + 1
		disagreement_component3 = float(disagree)/len(neighbors)

		components = components + "," + str(disagreement_component3)

		divergence = (1/3)*disagreement_component1 + (1/3)*disagreement_component2 + (1/3)*disagreement_component3

		all_divergence_components.append(components)
		all_divergences.append(divergence)


	return feature_dict, corr_feat_dist, all_corr_feat_dist_embd, all_feature_dict_embd, all_divergences, all_divergence_components


def run_GAPS(data, algo, data_instance_numbers = [16, 85, 9, 57]):

	algorithms = algo.split(',')
	print(algorithms)

	## Set features and target
	model_features, target = set_features_and_target(data)
	y = (data[target].values.reshape(-1, ))
	X_df = pd.DataFrame(data, columns=model_features)

	## Identify categorical features
	X_transformed, categorical_features, numeric_features, categorical_names = identify_and_transform_features(data, model_features)

	## Instantiate LAPS explainer

	explainer = GapsExplainer(X_df.values,
						    feature_names=model_features,
						    class_names=target,
						    categorical_features=categorical_features,
						    categorical_names=categorical_names,
						    discretize_continuous=False,
						    discretizer='quartile',
						    random_state=42)

	## generate perturbed neighborhood
	all_corr_feat_dist_embd = []
	all_feature_dict_embd = []
	all_sorted_index_combinations = []
	for algo in algorithms:

		df = pd.read_csv(staticfiles_storage.path("idle/temp/embedding_"+algo+".csv"))
		ld_embedding = np.array(df[['0', '1']])

		## generate perturbed neighborhoods, identify local feature contributions

		neighbors, globals()["neighbors_embd_"+algo], oversampled_data, globals()["oversampled_data_embd_"+algo], local_feature_contributions, globals()["local_feature_contributions_embd_"+algo], neighbors_local, globals()["neighbors_embd_local_"+algo] = explainer.generate_perturbed_neighborhood_global(
																				    X_df.values,
																				    X_transformed,
																				    ld_embedding,
																				    data_instance_numbers,
																				    model_features,
																				    categorical_features,
																				    numeric_features,
																				    nbrs=5,
																				    num_features=5)
		## Obtain Local explanations

		sorted_index_combinations, sorted_index_combinations_embd = get_local_explanations_for_GAPS(X_df, ld_embedding, data_instance_numbers, local_feature_contributions)

		print("Sorted Indexes original: ", sorted_index_combinations)
		print("Sorted Indexes embedding: ", sorted_index_combinations_embd)
		all_sorted_index_combinations.append(convert_matrix_to_array(sorted_index_combinations_embd, data_instance_numbers))
		sorted_indexes = convert_matrix_to_array(sorted_index_combinations, data_instance_numbers)
		
		## Compute local divergences

		local_divergences = compute_local_divergences(neighbors_local, globals()["neighbors_embd_local_"+algo], local_feature_contributions, globals()["local_feature_contributions_embd_"+algo])

		print("Local divergences: ", local_divergences)
		### Generate Bokeh plots for local neighborhoods

		"""
			To-do: Generate bokeh scatter plots for showing perturbed neighborhood -> First of the three returns
			For now we leave this one and only return the divergence scores
		"""

		## Explain the Neighborhoods in Original and Embedding
		
		globals()["corr_feat_dist_embd_"+algo], globals()["feature_dict_embd_"+algo], globals()["sorted_index_combinations_embd_"+algo] = explain_point_global(globals()["oversampled_data_embd_"+algo], model_features, categorical_features, numeric_features)
		all_corr_feat_dist_embd.append(globals()["corr_feat_dist_embd_"+algo])
		all_feature_dict_embd.append(globals()["feature_dict_embd_"+algo])

	corr_feat_dist, feature_dict, sorted_index_combinations = explain_point_global(oversampled_data, model_features, categorical_features, numeric_features)
	
	
	## Compute Global Divergence

	overal_divergences = []
	all_divergence_components = []
	for algo in algorithms:
		components = ""
		disagreements1 = pdist([corr_feat_dist, globals()["corr_feat_dist_embd_"+algo]], metric='euclidean')
		disagreements1 = 1/(1+disagreements1[0])
		components = components + str(disagreements1)

		disagreement2 = len(neighbors)-len(np.intersect1d(neighbors, globals()["neighbors_embd_"+algo]))
		disagreement2 = disagreement2/len(neighbors)
		components = components + "," + str(disagreement2)

		disagree = 0
		for index in range (0,len(neighbors)):
		    if neighbors[index] != globals()["neighbors_embd_"+algo][index]:
		        disagree = disagree + 1
		disagreement3 = float(disagree)/len(neighbors)
		components = components + "," + str(disagreement3)

		divergence = (1/3)*disagreements1 + (1/3)*disagreement2 + (1/3)*disagreement3


		overal_divergence = 0
		for index in range(0,len(local_divergences)):

		    overal_divergence = overal_divergence + (local_divergences[index] *(local_divergences[index]/divergence))
		
		overal_divergences.append((1/(1+overal_divergence)))
		all_divergence_components.append(components)

	return feature_dict, corr_feat_dist, all_corr_feat_dist_embd, all_feature_dict_embd, overal_divergences, sorted_indexes, all_sorted_index_combinations, local_divergences, all_divergence_components 

def convert_matrix_to_array(matrix, data_instance_numbers):
	array = []

	for i in range(0,len(matrix)):
		array.append(str(data_instance_numbers[matrix[i][0]])+"-"+str(data_instance_numbers[matrix[i][1]]))

	return array
