
import numpy as np
import umap, trimap
from sklearn.decomposition import FastICA
from MulticoreTSNE import MulticoreTSNE as M_TSNE
from sklearn.decomposition import PCA, KernelPCA, SparsePCA
from sklearn.manifold import TSNE, Isomap, MDS, LocallyLinearEmbedding, SpectralEmbedding, locally_linear_embedding

RANDOM_STATE = 42

def run_DR_Algorithm(name, data_features, params):

    """
    Runs each DR algorithm and returns the embedding.
    Parameters
    ----------
    name : String
        start time
    data_features : nD array
        original features
    int_dim : integer
        intrinsic dimensionality
    Returns
    ----------
    points : nD array
        embedding
    """

    if name == "UMAP":
        n_components = int(params.split(" ")[0])
        n_neighbors = int(params.split(" ")[1])
        min_dist = float(params.split(" ")[2])
        metric = params.split(" ")[3]
        reducer = umap.UMAP(n_neighbors=n_neighbors, min_dist=min_dist, n_components=n_components, metric=metric)
        points = reducer.fit_transform(data_features)
        
    elif name == "tSNE":
        n_components = int(params.split(" ")[0])
        perplexity = int(params.split(" ")[1])
        learning_rate = int(params.split(" ")[2])
        n_iter = int(params.split(" ")[3])
        tsne = TSNE(n_components=n_components, perplexity=perplexity, learning_rate=learning_rate, n_iter=n_iter, random_state=RANDOM_STATE)
        points = tsne.fit_transform(data_features)
        
    
    elif name == "PCA":
        n_components = int(params.split(" ")[0])
        svd_solver = params.split(" ")[1]
        pca = PCA(n_components=n_components, svd_solver=svd_solver)
        points = pca.fit_transform(data_features)
        

    elif name == "Trimap":
        n_inliers = int(params.split(" ")[0])
        n_outliers = int(params.split(" ")[1])
        n_random = int(params.split(" ")[2])
        distance = params.split(" ")[3]
        points = trimap.TRIMAP(n_inliers=n_inliers,
                          n_outliers=n_outliers,
                          n_random=n_random,
                          n_iters=1000,
                          distance=distance).fit_transform(data_features)


    elif name == "M_Core_tSNE":
        n_components = int(params.split(" ")[0])
        perplexity = int(params.split(" ")[1])
        learning_rate = int(params.split(" ")[2])
        n_jobs = int(params.split(" ")[3])
        tsne = M_TSNE(n_components=n_components, perplexity=perplexity, learning_rate=learning_rate, n_jobs=n_jobs)
        points = tsne.fit_transform(data_features)


    elif name == "MDS":
        n_components = int(params.split(" ")[0])
        max_iter = int(params.split(" ")[1])
        dissimilarity = params.split(" ")[2]
        mds = MDS(n_components=n_components, max_iter=max_iter, dissimilarity=dissimilarity)
        points = mds.fit_transform(data_features)


    elif name == "Isomap":
        n_components = int(params.split(" ")[0])
        n_neighbors = int(params.split(" ")[1])
        eigen_solver = params.split(" ")[2]
        neighbors_algorithm = params.split(" ")[3]
        isomap = Isomap(n_components=n_components, n_neighbors=n_neighbors, eigen_solver=eigen_solver, neighbors_algorithm=neighbors_algorithm)
        points = isomap.fit_transform(data_features)


    elif name == "KernelPCA":
        n_components = int(params.split(" ")[0])
        kernel = params.split(" ")[1]
        eigen_solver = params.split(" ")[2]
        max_iter = int(params.split(" ")[3])
        kpca = KernelPCA(n_components=n_components, kernel=kernel, eigen_solver=eigen_solver, max_iter=max_iter)
        points = kpca.fit_transform(data_features)

    return points














