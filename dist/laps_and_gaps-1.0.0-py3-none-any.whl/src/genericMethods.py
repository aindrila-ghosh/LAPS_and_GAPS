## imports for running DR algorithms

import math
import coranking
import numpy as np
import pandas as pd

## imports for genereting the plots

from bokeh.layouts import row
from bokeh.models import HoverTool
from bokeh.embed import components
from bokeh.models.glyphs import Text
from bokeh.plotting import figure, output_file, show, ColumnDataSource

## Latest additions for rep-data points and subset selection

from sklearn import svm
import scipy.spatial as spatial
from sklearn.cluster import KMeans
from sklearn.metrics import pairwise_distances
from sklearn.neighbors import NearestNeighbors
from sklearn.metrics import pairwise_distances_argmin_min

## imports from my files

from .DR_algorithms import run_DR_Algorithm
from .metrics import calculate_dimRed_metrics, run_K_max_ordering
from .Preprocessing import set_features_and_target, identify_and_transform_features

## My methods

def get_metric_graphs(algos, metric_vals, metric_name):
	plot = figure(x_range=algos, plot_height=250, title=metric_name)
	plot.vbar(x=algos, top= metric_vals, width=0.9)
	plot.xgrid.grid_line_color = None
	plot.y_range.start = 0
	return plot

def get_dataset(dataset):
	data = pd.read_csv('data/'+dataset+'.csv')
	return data

def run_DR_Algos(data, algo, params, method):

	'''
	To-do: remove points from return, we are generating intermediate files anyway
	'''
	model_features, target = set_features_and_target(data)
	X_transformed, categorical_features, numeric_features, categorical_names = identify_and_transform_features(data, model_features)
	points = run_DR_Algorithm(algo, X_transformed, params)

	y = (data[target].values.reshape(-1, ))
	X_df = pd.DataFrame(data, columns=model_features)

	#print(X_df.head())
	if method == "laps":
		rep_points = generate_representative_points(20, X_df, X_transformed, y, points)
	if method == "gaps":
		rep_subsets = generate_representative_subset(20, X_df)
	
	points = np.append(points, np.array(data[target]), axis = 1)
	pd.DataFrame(points).to_csv("idle/static/idle/temp/embedding_"+algo+".csv", index=False)

	cr_matrix = coranking.coranking_matrix(data, points)

	#cr_matrix = []
	
	
	AUC_lnK_R_NX, mean_R_NX, Q_local, Q_global, K_max = calculate_dimRed_metrics(points, data[model_features].values)
	K_max_ordering = run_K_max_ordering(data[model_features].values, points, K_max)
	print("AUC_lnK_R_NX: ", AUC_lnK_R_NX)
	print("mean_R_NX: ", mean_R_NX)
	print("Q_local: ", Q_local)
	print("Q_global: ", Q_global)
	print("K_max: ", K_max)
	print("K_max_ordering: ", K_max_ordering)

	if method == "laps":
		return AUC_lnK_R_NX, mean_R_NX, Q_local, Q_global, K_max, cr_matrix, points, rep_points
	else:
		return AUC_lnK_R_NX, mean_R_NX, Q_local, Q_global, K_max, cr_matrix, points, rep_subsets

def convert_dict_to_list(input_dict):
	result = []
	for k, v in input_dict.items():
		result.append([k, round(v,5)])
	return result

def get_scatter_plots(points, testText):
	indexes = [i for i in range(0,len(points))]

	source = ColumnDataSource(
	        data=dict(
	            x=points[:,0],
	            y=points[:,1],
	            indexes = indexes
	        )
	    )

	hover = HoverTool(
	        tooltips=[
	            ("index", "$index"),
	            ("(x,y)", "($x, $y)"),
	        ]
	    )

	plot = figure(title = testText, x_axis_label = 'X-Axis', y_axis_label= 'Y-Axis', plot_width = 400, plot_height= 400, tools=[hover])
	glyph = Text(x="x", y="y", text='indexes', x_offset=7, y_offset=7, text_font_size="9pt", text_color="grey")
	plot.circle( points[:,0], points[:,1], size = 10, color='navy', alpha=0.5)
	plot.add_glyph(source, glyph)

	return plot

def get_neighborhood_plots_LAPS(points, neighbors, data_instance_number):
	indexes = []
	for i in range(0,len(points)):
	    if i in neighbors:
	        indexes.append(str(i))
	    else:
	        indexes.append('')

	colors = []
	for i in range(0,len(points)):
	    if i == data_instance_number:
	        colors.append('Orange')
	        continue
	    elif i in neighbors:
	        colors.append('Brown')
	        continue
	    else:
	        colors.append('LightGray')

	source = ColumnDataSource(
        data=dict(
            x=points[:,0],
            y=points[:,1],
            all_colors = colors,
            indexes = indexes
        )
    )

	hover = HoverTool(
	        tooltips=[
	            ("index", "$index"),
	            ("(x,y)", "($x, $y)"),
	        ]
	    )

	p = figure(plot_width=700, plot_height=450, tools=[hover],)
	glyph = Text(x="x", y="y", text='indexes', x_offset=7, y_offset=7, text_font_size="15pt", text_color="Black")
	p.circle('x', 'y', fill_color='all_colors', line_color='white', size=17, source=source)
	p.add_glyph(source, glyph)

	return p

def gen_feature_influence_plots(feature_dict):
	bar_color = []
	y_offset_val = []
	label = []
	for item in feature_dict.values():
	    label.append("{0:.2f}".format(item))
	    if item<0:
	        bar_color.append('#e34a33')
	        y_offset_val.append(item+15)
	    else:
	        bar_color.append('#2ca25f')
	        y_offset_val.append(item)
	        
	        
	source = ColumnDataSource(
	        data=dict(
	            x_val = list(feature_dict.keys()),
	            y_val = list(feature_dict.values()),
	            y_offset = y_offset_val,
	            labels =  label,
	            color = bar_color
	        )
	    )

	p = figure(x_range=list(feature_dict.keys()), plot_height=380, toolbar_location=None, tools="")

	glyph = Text(x="x_val", y="y_val", text='labels', x_offset=-15, y_offset='y_offset', text_font_size="13pt", text_font_style = 'bold', text_color="black")

	p.vbar(x="x_val", top="y_val", color="color", width=0.9, source=source)
	p.xaxis.major_label_orientation = math.pi/7
	p.xaxis.major_label_text_font_size = '13pt'
	p.yaxis.major_label_text_font_size = '12pt'
	p.xaxis.major_label_text_font_style = 'bold'
	p.yaxis.major_label_text_font_style = 'bold'
	p.min_border_left = 82
	p.xgrid.grid_line_color = None
	p.xaxis.axis_label_text_align = 'center'
	p.y_range.start = np.min(list(feature_dict.values()))-0.05
	p.y_range.end = np.max(list(feature_dict.values()))+0.01
	p.add_glyph(source, glyph)

	return p

def find_density_based_outliers(data, budget):
	density = []
	radius = 100
	
	point_tree = spatial.cKDTree(data)
	for index in range(0,data.shape[0]):
		density.append(len(point_tree.indices[point_tree.query_ball_point(data[index], radius)]))
	#print(np.argsort(np.array(density))[::-1])
	
	return np.argsort(np.array(density))[::-1][:budget]


def find_points_with_highest_density(X_df, budget):
	density = []
	point_tree = spatial.cKDTree(X_df.values)
	for index in range(0,X_df.shape[0]):
	        density.append(len(point_tree.indices[point_tree.query_ball_point(X_df.values[index], 100)]))

	#print(type(np.array(density)))
	#print(np.argsort(np.array(density))[::-1])
	return np.argsort(np.array(density))[::-1][:budget]

def find_misplaced_points(X_transformed, ld_embedding, budget):

	misplaced_neighbor_count = []

	for index in range (0,X_transformed.shape[0]):
		knn = NearestNeighbors(leaf_size=30, n_neighbors=15, p=2, radius=1.0, algorithm='ball_tree')

		knn.fit(X_transformed)
		neighbors = knn.kneighbors(X_transformed, return_distance=False)[index]

		knn.fit(ld_embedding)
		neighbors_embd = knn.kneighbors(ld_embedding, return_distance=False)[index]

		misplaced_neighbor_count.append(len(neighbors)-len(np.intersect1d(neighbors, neighbors_embd)))

    #print(np.argsort(np.array(misplaced_neighbor_count))[::-1])
    #print(misplaced_neighbor_count)
	return np.argsort(np.array(misplaced_neighbor_count))[::-1][:budget]

def find_points_close_to_decision_boundary(X_df, y, budget):
	svc = svm.SVC(kernel='linear').fit(X_df, y)
	decision = svc.decision_function(X_df)
	w_norm = np.linalg.norm(svc.coef_)
	dist = decision / w_norm
	#print(np.argsort(dist))

	return np.argsort(dist)[:budget]

def find_cluster_centres(X_df, clusters=2):
	kmeans = KMeans(n_clusters=clusters, random_state=0).fit(X_df)
	closest, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, X_df)
	return closest


def generate_dissimilarity_density_based_subset(budget, X_df):
	k = 10

	selected = []
	active_status = {}
	density = []
	point_tree = spatial.cKDTree(X_df.values)
	knn = NearestNeighbors(leaf_size=30, n_neighbors=k, p=2, radius=1.0, algorithm='ball_tree')
	knn.fit(X_df)
    
    ## Find density of all points
    
	for index in range(0,X_df.shape[0]):
		density.append(len(point_tree.indices[point_tree.query_ball_point(X_df.values[index], 100)]))
		active_status.update({index : 'active'})
    # end for
    
    ## order points based on density
	ordered_density = np.argsort(np.array(density))[::-1]  ## ordered in descending order

    ## select the point with the highest density
	for index in range(0,X_df.shape[0]):
		active_array = []
        
        ## if the point is active and is not already a part of selected
		if active_status[ordered_density[index]] == 'active' and ordered_density[index] not in selected:
            
            ## Add point into selected
			selected.append(ordered_density[index])  
			nbrs = knn.kneighbors(X_df, return_distance=False)[ordered_density[index]]
            
            # Find its neighbors and change their status to inactive
			for nbr_index in range(0,len(nbrs)):
				active_status[nbrs[nbr_index]] = 'inactive'
            
            # for all the remaining active points in the active_status array, find their distances with the selected point
			for active_index in range(0,X_df.shape[0]):
				if active_status[active_index] == 'active':
					active_array.append(X_df.values[active_index])
            
			# print(X_df.values[ordered_density[index]].reshape(1, -1))
			# print(X_df.values[ordered_density[index]].reshape(-1, 1))

			distances = pairwise_distances(
									active_array,
									X_df.values[ordered_density[index]].reshape(1, -1),
									metric='euclidean'
									).ravel()
            
            # Add the point with the highest distance from selected to the selected array
            # find its nearest neighbors and turn them to inactive
			counter = 0
			for active_index in range(0,X_df.shape[0]):
				if active_status[active_index] == 'active':
					counter = counter + 1
					if counter == np.argmax(distances):
						selected.append(active_index)
						nbrs_new = knn.kneighbors(X_df, return_distance=False)[active_index]
            
						for nbr_index in range(0,len(nbrs_new)):
							active_status[nbrs_new[nbr_index]] = 'inactive'
            
            # if all active points are exhausted and budget has not yet reached
            #make everything active again and start from the beginning
            
			if index == X_df.shape[0] and len(selected) < budget:
				for active_index in range(0,X_df.shape[0]):
					active_status[active_index] = 'active'
				index = 0
				continue
            
            # otherwise stop
			if len(selected) > budget:
				selected = selected[:-1]
            
			if len(selected) == budget:
				break
                
    # return the selected subset of datapoints        
	return selected

def generate_cluster_based_subset(budget, X_df):

	kmeans = KMeans(n_clusters=2, random_state=0).fit(X_df)
	closest, _ = pairwise_distances_argmin_min(kmeans.cluster_centers_, X_df)
	closest

	knn = NearestNeighbors(leaf_size=30, n_neighbors=15, p=2, radius=1.0, algorithm='ball_tree')
	knn.fit(X_df)
	nbrs = knn.kneighbors(X_df, return_distance=False)[closest[0]]
	nbrs1 = knn.kneighbors(X_df, return_distance=False)[closest[1]]

	if budget % 2 == 0:
		half_budget_1 = int(budget/2)
		half_budget_2 = half_budget_1
	else:
		half_budget_1 = int(budget/2)
		half_budget_2 = budget - half_budget_1


	#nbrs[:half_budget_1].tolist().extend(nbrs1[:half_budget_2].tolist())
	subset = np.concatenate([np.array(nbrs[:half_budget_1]),np.array(nbrs1[:half_budget_2])]).tolist()

	# print("############ cluster based ############")
	# print("subset", subset)
	# print(type(subset))
	# print(np.concatenate([np.array(nbrs[:half_budget_1]),np.array(nbrs1[:half_budget_2])]).tolist())

	# print("******************")
	
	return subset

def generate_representative_points(budget, data, data_transformed, target, ld_embedding):
	rep_points = []

	rep_points.append(find_density_based_outliers(data.values, budget).tolist())
	rep_points.append(find_points_with_highest_density(data, budget).tolist())
	rep_points.append(find_misplaced_points(data_transformed, ld_embedding, budget).tolist())
	rep_points.append(find_points_close_to_decision_boundary(data, target, budget).tolist())
	rep_points.append(find_cluster_centres(data).tolist())

	return rep_points

def generate_representative_subset(budget, data):
	rep_subsets = []

	rep_subsets.append(generate_dissimilarity_density_based_subset(budget, data))
	rep_subsets.append(generate_cluster_based_subset(budget, data))

	return rep_subsets

