## Basic imports and variables

import random
RANDOM_STATE = 42
import numpy as np
import pandas as pd

## imports for dim_Red

import rpy2
import rpy2.robjects.numpy2ri
import rpy2.robjects as robjects
import rpy2.robjects.packages as rpackages
from rpy2.robjects.vectors import StrVector
from rpy2.robjects import pandas2ri

## imports for 1-NN gen error

from sklearn.neighbors import NearestNeighbors
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import cross_val_score, LeaveOneOut


def calculate_dimRed_metrics(points, df_sample):

    """
    Computes metrics based on correlation matrix

    Parameters
    ----------
    points : nD array
        embedding
    df_sample : nD array
        original data
    Returns
    ----------
    AUC_log_R_NX : float
    mean_R_NX : float
    Q_local : float
    Q_global : float
    K_max : integer
    """

    base = rpackages.importr('base')
    packnames = ('dimRed')

    if all(rpackages.isinstalled(x) for x in packnames):
        installed = True
    else:
        utils = rpackages.importr('utils')
        utils.chooseCRANmirror(ind=1) 
        utils.install_packages(StrVector(packnames))

    rpy2.robjects.numpy2ri.activate()
    pandas2ri.activate()
    dimRed = rpackages.importr('dimRed')

    nr,nc = points.shape
    Pointsr = robjects.r.matrix(points, nrow=nr, ncol=nc)
    robjects.r.assign("points", Pointsr)

    nr,nc = df_sample.shape
    df_sample_matrix = robjects.r.matrix(df_sample, nrow=nr, ncol=nc)
    robjects.r.assign("df_sample", df_sample_matrix)
    
    drObject = dimRed.dimRedData(data=Pointsr, meta=df_sample)

    params = {'data': drObject, 'org.data': df_sample_matrix, 'has.org.data' : True}
    drResultObject = dimRed.dimRedResult(**params)

    AUC_log_R_NX = float(dimRed.AUC_lnK_R_NX(drResultObject))
    mean_R_NX = dimRed.mean_R_NX(drResultObject)
    Q_local = dimRed.Q_local(drResultObject)
    Q_global = dimRed.Q_global(drResultObject)
    K_max = np.argmax(dimRed.LCMC(drResultObject))
    
    return AUC_log_R_NX, mean_R_NX, Q_local, Q_global, K_max


def run_K_max_ordering(features, points, k_max):
    
    """
    Computes K_max ordering of the data points

    Parameters
    ----------
    features : nD array
        original features
    points : nD array
        embedding 
    k_max : float
        value of k_max
    Returns
    ----------
    np.mean(mean_K_max_ordering) : float
        k_max ordering
    """
    
    if k_max <= 0:
        k_max = 1
    mean_K_max_ordering = []
    knn = NearestNeighbors(leaf_size=30, n_neighbors=k_max, p=2, radius=1.0, algorithm='ball_tree')
    knn_embd = NearestNeighbors(leaf_size=30, n_neighbors=k_max, p=2, radius=1.0, algorithm='ball_tree')
    knn.fit(features)
    knn_embd.fit(points)

    for index in range(0, len(features)):
        neighbors = knn.kneighbors(features, return_distance=False)[index]
        neighbors_embd = knn_embd.kneighbors(points, return_distance=False)[index]
        mean_K_max_ordering.append(len(np.intersect1d(neighbors, neighbors_embd))/len(neighbors))
        
    return np.mean(mean_K_max_ordering)


def gen_error_1_NN(embedding, labels):
    
    """
    Computes 1-NN generalization error

    Parameters
    ----------
    embedding : nD array
        embedding
    labels : list
        original labels
    Returns
    ----------
    gen_error : float
       generalization error
    """
   
    model = KNeighborsClassifier(n_neighbors=1)
    loo = LeaveOneOut()
    loo.get_n_splits(embedding)
    scores = cross_val_score(model , X = embedding , y = labels, cv = loo)
    gen_error = (1 - np.mean(scores))
    
    return gen_error
